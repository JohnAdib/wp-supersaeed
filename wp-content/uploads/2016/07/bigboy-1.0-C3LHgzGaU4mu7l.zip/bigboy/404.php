<?php get_header(); ?>

<div id="page404">
<a href=" <?php bloginfo('url'); ?>"> <div></div></a>
</div>
<!-- <?php bloginfo('url'); ?> -->

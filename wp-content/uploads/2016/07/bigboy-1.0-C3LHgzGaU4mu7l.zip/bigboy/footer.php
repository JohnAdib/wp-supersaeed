<footer >
	<?php wp_nav_menu(['theme_location' => 'menu_footer']); ?>
	<div id="copyright">طراحی شده توسط <a href="https://github.com/mohammadalisalehi">محمدعلی</a> در <a href="http://ermile.com/fa">ارمایل</a> &copy; 2016<?php
		$currentYear = date('Y');
		if (2016 < $currentYear)
		{
			echo '-' . $currentYear;
		}
		?>
	 </dive>
</footer>
</body>
</html>